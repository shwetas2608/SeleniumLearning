package testNG;

public class Loadbrowser {

}
