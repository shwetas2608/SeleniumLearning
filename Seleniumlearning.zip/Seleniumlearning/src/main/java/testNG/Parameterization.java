package testNG;

public class Parameterization {

}
