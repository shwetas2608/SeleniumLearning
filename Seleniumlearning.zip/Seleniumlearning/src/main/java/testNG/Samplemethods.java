package testNG;

import org.testng.annotations.Test;

public class Samplemethods {
	
	@Test
	public void test1(){	
		System.out.println("I am stupid");
	}

}
