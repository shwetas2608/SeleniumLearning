package utils;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	//Objective: Reading Excel
	
	//1. Read the file location
	//2. Create an object for workbook
	//3. Go to worksheet
	//4. Row iteration and get row value
	//5. Cell iteration and get cell value
	public void readExcelData(){
		XSSFWorkbook workbook = new XSSFWorkbook("./data/TC002.xlsx");
	}
	
	
}
