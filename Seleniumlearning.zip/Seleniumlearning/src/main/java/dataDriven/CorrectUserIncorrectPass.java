package dataDriven;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CorrectUserIncorrectPass {
	@Test
	@Parameters({"userName", "password"})
	public void correctUserIncorrectPass(String userName, String pass) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
			
		WebElement username = driver.findElementById("txtUsername");
		username.sendKeys(userName);
		
		WebElement password =driver.findElementById("txtPassword");
		password.sendKeys(pass);
		
		WebElement login = driver.findElementById("btnLogin");
		login.click();
	}
}
