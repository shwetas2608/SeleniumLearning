package dataDriven;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class loginTestCase {
	
	String data[][] = {
			{"Admin","Admin123"},
			{"Admin","fdsfsdf"},
			{"dssda","Admin123"},
			{"daasdsad","ssadds"},
	};
	
	@DataProvider(name="loginData")
	public String[][] loginTestData(){
		return data;
	}
	

	@Test(dataProvider="loginData")
	public void loginFunction(String userName, String pass){
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
			
		WebElement username = driver.findElementById("txtUsername");
		username.sendKeys(userName);
		
		WebElement password =driver.findElementById("txtPassword");
		password.sendKeys(pass);
		
		WebElement login = driver.findElementById("btnLogin");
		login.click();
	}

}
