package learning;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstScript {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		
		//Initialize Chrome browser
		ChromeDriver driver = new ChromeDriver();
		
		//Open a site
		driver.get("https://www.google.com");
		
		//Maximize browser window
		driver.manage().window().maximize();
		
		WebElement textbox = driver.findElementByName("q");
		textbox.sendKeys("india");
		
//		driver.quit();
		
	}

}
