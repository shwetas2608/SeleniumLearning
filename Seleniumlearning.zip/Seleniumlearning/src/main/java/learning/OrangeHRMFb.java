package learning;

import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class OrangeHRMFb {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		WebElement fbLink = driver.findElementByXPath("//img[@alt='OrangeHRM on Facebook']");	
		fbLink.click();
		
		Set<String> allHandles = driver.getWindowHandles();
		
		for(String handle: allHandles){
			driver.switchTo().window(handle);
			System.out.println(driver.getTitle());
		}

	}

}
