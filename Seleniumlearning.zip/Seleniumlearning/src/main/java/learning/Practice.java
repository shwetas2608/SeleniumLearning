package learning;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Practice {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe" );
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leafground.com/pages/autoComplete.html");
		driver.manage().window().maximize();
		
		WebElement input = driver.findElementById("tags");
		input.sendKeys("s");
		
		Thread.sleep(3000);
		
		List<WebElement> optionlist = driver.findElementsByXPath("//*[@id=\"ui-id-1\"]/li");
		int size = optionlist.size();
		System.out.println(size);
		
		for(WebElement webelement:optionlist){
			if (webelement.getText().equals("Web Services")){
				webelement.click();
				break;
			}
			
			
			
		}

		
		
		
				
		
	

	}
}
