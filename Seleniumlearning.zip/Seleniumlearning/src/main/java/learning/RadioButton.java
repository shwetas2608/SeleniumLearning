package learning;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButton {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://www.leafground.com/pages/radio.html");
		
		WebElement button1 = driver.findElementById("yes");
		button1.click();
		
		WebElement firstButton = driver.findElementByXPath("//*[@id='contentblock']/section/div[2]/div/div/input[1]");
		WebElement secondButton = driver.findElementByXPath("//*[@id='contentblock']/section/div[2]/div/div/input[2]");
		
		Boolean isFirstSelected = firstButton.isSelected();
		Boolean isSecondSelected = secondButton.isSelected();
		
		System.out.println("First Button Selected: "+isFirstSelected);
		System.out.println("Second Button Selected: "+isSecondSelected);
		
		driver.quit();
		
		

	}

}
