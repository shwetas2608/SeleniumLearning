package learning;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Buttons {

	public static void main(String[] args) {

		System.setProperty("webdriver,chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("http://www.leafground.com/pages/Button.html");
		
		WebElement home = driver.findElementById("home");
//		home.click();
		
		WebElement position = driver.findElementById("position");
		Point xylocation = position.getLocation();
		
		int xPosition = xylocation.getX();
		int yPosition = xylocation.getY();
		
		System.out.println(xylocation);
		
		System.out.println("X Position is: "+xPosition+ " Y Position is: "+yPosition);
		
		WebElement color = driver.findElementById("color");
		
		String colorButton = color.getCssValue("background-color");
		
		System.out.println(colorButton);
		
		
		WebElement Button4= driver.findElementById("size");
		int height = Button4.getSize().getHeight();
		int width = Button4.getSize().getWidth();
		
		System.out.println("Height of a button :"+height);
		System.out.println("Width of a button :"+width);

		WebElement Button1 = driver.findElementById("home");
		Button1.click();
				
		

	}

}
