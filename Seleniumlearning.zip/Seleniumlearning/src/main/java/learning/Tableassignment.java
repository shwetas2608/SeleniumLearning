package learning;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Tableassignment {

	public static void main(String[] args) {
		// TODO Auto-generatesd method stub
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		driver.get("http://leafground.com/pages/table.html");

		driver.manage().window().maximize();
	
		List<WebElement> Column = driver.findElementsByTagName("th");
		int size = Column.size();
		System.out.println("Total number of coloumns present: "+size);
		
		List<WebElement> row = driver.findElementsByTagName("tr");
		int size1 = row.size();
		System.out.println("Total number of rows present:"+size1);
		
		WebElement locator  = driver.findElementByXPath("//*[@id='contentblock']/section/div[1]/table/tbody/tr[3]/td[2]/font");
		String  progress = locator.getText();
		System.out.println(progress);
		
		
		WebElement vital = driver.findElementByXPath("//*[@id='contentblock']/section/div[1]/table/tbody/tr[6]/td[3]");
		vital.click();
		
		

	}

}
