package learning;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Textbox {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		
		//Initialize Chrome browser
		ChromeDriver driver = new ChromeDriver();
				
		//Open a site
		driver.get("http://www.leafground.com/pages/Edit.html");
		
		driver.manage().window().maximize();
		
		WebElement email = driver.findElementByXPath("//*[@id='email']");
		email.sendKeys("shwetas2608@gmail.com");
		
		WebElement append = driver.findElementByXPath("//*[@id='contentblock']/section/div[2]/div/div/input");
		append.sendKeys("appended");

		WebElement clearme = driver.findElementByXPath("//*[@id='contentblock']/section/div[4]/div/div/input");
		clearme.clear();
		
		WebElement defaultext = driver.findElementByXPath("<input type='text' name='username' value='TestLeaf' align='left' style='width:350px'>");
		String value = defaultext.getAttribute("value");
		
		System.out.println(value);
	}

}
