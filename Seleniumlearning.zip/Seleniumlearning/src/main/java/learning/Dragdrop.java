package learning;

import java.awt.Desktop.Action;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Dragdrop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("http://www.leafground.com/pages/frame.html");
		WebElement dragelement = driver.findElementById("drragable");
		WebElement dropelement = driver.findElementById("droppable");
		
		Actions action = new Actions(driver);
		//action.clickAndHold(DragElement).moveToElement(DropElement).release(DropElement).build().perform();
		
		action.dragAndDrop(dragelement, dropelement).build().perform();
		
		

	}
}
